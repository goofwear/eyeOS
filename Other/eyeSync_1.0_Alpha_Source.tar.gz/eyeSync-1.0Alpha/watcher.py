#!/usr/bin/python
# -*- coding: UTF8 -*-
#
# eyeSync 1.0Alpha
#
# Copyright 2008 eyeOS Team (team@eyeos.org)
#
# http://www.eyeos.org/
#
# Licensed under the terms of the GNU General Public License 3 (gpl3).
# See LICENSE for details.
#

import os
import sys
from PyQt4 import QtCore, QtGui
from PyQt4.QtCore import QObject, QThread
import threading
from config import studioConfig
from xmlrpc import myXmlRpc
from time import strftime
import platform
import popen2
from charset import localCharset

try:
    from pyinotify import WatchManager, Notifier, ThreadedNotifier, EventsCodes, ProcessEvent
except ImportError:
    try:
        import win32file
        import win32con
    except ImportError:
        print "darwin"

class FileSystemWatcher(QtCore.QObject):
    def __init__(self,path):
        self.myPath = path
        self.thread = ThreadWatcher ( self.myPath )
        return None
    
    def start(self):
        self.thread.start()
    	return None
    def stop(self):
        return None
    def output(self,text):
        print str(text)

if sys.platform == 'linux2':
    class FileSystemEventProcess(ProcessEvent):
        def __init__(self,father):
            self.config = studioConfig()
            self.syncs = self.config.getSyncs()
            self.xmlrpc = myXmlRpc()
            self.dad = father
            self.moving = ""
        def process_default(self, event):
            myCharset = localCharset().getCharset()
            eventname = event.event_name
            decoded_name = event.name.decode(myCharset)
            eventfile = event.path+'/'+decoded_name
            obj = self.config.getObjByLocalSync(event.path)
            pathtofile = obj[1]+'/'+eventfile[len(obj[0]):]
            if self.moving != "":
                if eventname == 'IN_MOVED_TO' or eventname == 'IN_MOVED_TO|IN_ISDIR':
                   pathtofileto = obj[1]+'/'+eventfile[len(obj[0]):]
                   pathtofile = obj[1]+'/'+self.moving[len(obj[0]):]
                   self.xmlrpc.renameFile(pathtofile,pathtofileto)
                   self.dad.send('['+strftime("%H:%M")+'] Renamed: '+self.moving+' to '+eventfile)
                else:
                    pathtofile = obj[1]+'/'+self.moving[len(obj[0]):]
                    self.dad.send('['+strftime("%H:%M")+'] Deleted: '+self.moving)
                    self.xmlrpc.deleteFile(self.moving, pathtofile)
                self.moving=""
            else:
                if eventname == 'IN_CLOSE_WRITE':
                    self.dad.send('['+strftime("%H:%M")+'] Modified: '+eventfile)
                    self.xmlrpc.updateFile(eventfile, pathtofile)
                elif eventname == 'IN_CREATE':
                    if os.path.isdir(eventfile):
                        self.dad.send('['+strftime("%H:%M")+'] Directory created: '+eventfile)
                        self.xmlrpc.mkdir(pathtofile)
                    else:
                        self.dad.send('['+strftime("%H:%M")+'] Created: '+eventfile)
                        self.xmlrpc.updateFile(eventfile,pathtofile)
                elif eventname == 'IN_MOVED_TO':
                    self.dad.send('['+strftime("%H:%M")+'] Created: '+eventfile)
                    self.xmlrpc.createFile(eventfile,pathtofile)    
                elif eventname == 'IN_DELETE':
                    self.dad.send('['+strftime("%H:%M")+'] Deleted: '+eventfile)
                    self.xmlrpc.deleteFile(eventfile, pathtofile)
                elif eventname == 'IN_MOVED_FROM':
                    self.moving = eventfile
                elif eventname == 'IN_MOVED_FROM|IN_ISDIR':
                    self.moving = eventfile
                elif eventname == 'IN_CREATE|IN_ISDIR':
                    self.dad.send('['+strftime("%H:%M")+'] Directory created: '+eventfile)
                    self.xmlrpc.mkdir(pathtofile)
                elif eventname == 'IN_DELETE|IN_ISDIR':
                    self.dad.send('['+strftime("%H:%M")+'] Directory Deleted: '+eventfile)
                    self.xmlrpc.deleteFile(eventfile, pathtofile)
        
    class ThreadWatcher(QThread):
        def __init__ ( self, path):
            self.myPath = path
            self.eventProcess = FileSystemEventProcess(self)
            QThread.__init__(self)
        def run(self):
            mask = EventsCodes.ALL_EVENTS
            wm = WatchManager()
            notifier = Notifier(wm, self.eventProcess)
            wm.add_watch(self.myPath, mask, rec = True, auto_add = True)
            while True:
                try:
                    notifier.process_events()
                    if notifier.check_events():
                        notifier.read_events()
                except KeyboardInterrupt:
                    notifier.stop()
                    break
        def send(self,text):
            self.emit(QtCore.SIGNAL("reply(QString)"),QtCore.QString(text))
elif sys.platform == 'darwin':
    class FileSystemEventProcess:
        def __init__(self,father):
            self.config = studioConfig()
            self.syncs = self.config.getSyncs()
            self.xmlrpc = myXmlRpc()
            self.dad = father
        def process_default(self, event, eventfile):
            obj = self.config.getObjByLocalSync(eventfile)
            x = len(obj[0])
            pathtofile = obj[1]+'/'+eventfile[x:]
            if event == 'MODIFIED':
                self.dad.send('['+strftime("%H:%M")+'] Modified: '+eventfile)
                self.xmlrpc.updateFile(eventfile, pathtofile)
            elif event == 'DELETE':
                self.dad.send('['+strftime("%H:%M")+'] Deleted: '+eventfile)
                self.xmlrpc.deleteFile(eventfile, pathtofile)
            elif event == 'CREATE':
				self.dad.send('['+strftime("%H:%M")+'] Created: '+eventfile)
				self.xmlrpc.createFile(eventfile,pathtofile)
            elif event == 'MKDIR':
				self.dad.send('['+strftime("%H:%M")+'] New Directory: '+eventfile)
				self.xmlrpc.mkdir(pathtofile)
            return None
        def process_rename(self, eventfilefrom, eventfileto):
            obj = self.config.getObjByLocalSync(eventfilefrom)
            x = len(obj[0])
            pathtofilefrom = obj[1]+'/'+eventfilefrom[x:]
            obj = self.config.getObjByLocalSync(eventfileto)
            x = len(obj[0])
            pathtofileto = obj[1]+'/'+eventfileto[x:]
            self.xmlrpc.renameFile(pathfilefrom,pathfileto)
            return None
        
    class ThreadWatcher(QThread):
        def __init__ ( self, path):
            self.myPath = path
            self.eventProcess = FileSystemEventProcess(self)
            QThread.__init__(self)
        def run(self):
            r, w, e = popen2.popen3('/usr/bin/gfs')
            while True:
                data = r.readline()
                data = data[:-1]
                content = data.split('|')
                i = len(self.myPath)
                subpath = content[1][:i]
                if self.myPath == subpath:
                    if content[0] == 'RENAME':
                        subpath = content[2][:i]
                        if self.myPath == subpath:
                            self.eventProcess.process_rename(content[1], content[2])
                        else:
                            self.eventProcess.process_default('DELETE', content[1])
                    else:        
                        self.eventProcess.process_default(content[0], content[1])
                else:
                    if content[0] == 'RENAME':
                        subpath = content[2][:i]
                        if self.myPath == subpath:
                            self.eventProcess.process_default('CREATE', content[2])
            return None
        def send(self,text):
            self.emit(QtCore.SIGNAL("reply(QString)"),QtCore.QString(text))
    



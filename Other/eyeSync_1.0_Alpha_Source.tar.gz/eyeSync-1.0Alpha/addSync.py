#!/usr/bin/python
# -*- coding: UTF8 -*-
#
# eyeSync 1.0Alpha
#
# Copyright 2008 eyeOS Team (team@eyeos.org)
#
# http://www.eyeos.org/
#
# Licensed under the terms of the GNU General Public License 3 (gpl3).
# See LICENSE for details.
#

import sys
import os
from PyQt4 import QtGui, QtCore
from config import studioConfig
from PyQt4.QtCore import QObject, QThread

class Ui_Sync(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        myWidth = 520
        myHeight = 180
        Form.resize(QtCore.QSize(QtCore.QRect(0,0,myWidth,myHeight).size()).expandedTo(Form.minimumSizeHint()))
        
        screen = QtGui.QDesktopWidget().screenGeometry()
        Form.move((screen.width()-myWidth)/2, (screen.height()-myHeight)/2)
        
        Form.setWindowTitle('Add folder to sync')
        
        self.labelInfo = QtGui.QLabel("Select a folder from your computer to synchronize with a folder of your eyeOS",Form)
        self.labelInfo.move(20,10)
        
        self.labelLocal = QtGui.QLabel("Local folder",Form)
        self.labelLocal.move(20,60)
        
        self.labelRemote = QtGui.QLabel("eyeOS folder",Form)
        self.labelRemote.move(20,90)
        
        
        self.okB = QtGui.QPushButton("Ok",Form)
        self.okB.setGeometry(QtCore.QRect(440,145,70,25))
        
        self.cancelB = QtGui.QPushButton("Cancel",Form)
        self.cancelB.setGeometry(QtCore.QRect(360,145,70,25))
        
        self.lineLocal = QtGui.QLineEdit(Form)
        self.lineLocal.setGeometry(QtCore.QRect(130,60,300,20))
        
        self.lineRemote = QtGui.QLineEdit(Form)
        self.lineRemote.setGeometry(QtCore.QRect(130,90,380,20))
        
        self.browse = QtGui.QPushButton("Browse",Form)
        self.browse.setGeometry(QtCore.QRect(440,60,70,20))
        
        
class SyncDlg(QtGui.QDialog):

    def __init__(self,uiDlg):

        QtGui.QDialog.__init__(self)
        
        self.ui = Ui_Sync()
        self.ui.setupUi(self)
        
        self.mainUi = uiDlg
        
        self.connect(self.ui.okB, QtCore.SIGNAL("clicked()"),self.accept)
        self.connect(self.ui.cancelB, QtCore.SIGNAL("clicked()"),self.cancel)
        self.connect(self.ui.browse, QtCore.SIGNAL("clicked()"),self.browsing)

    def accept(self):
        self.local = str(self.ui.lineLocal.text())
        self.remote = str(self.ui.lineRemote.text())
        if self.local == "" or self.remote == "":
            QtGui.QMessageBox.warning(None,"Error","You should fill all the fields")
            return None
        if not os.path.isdir(self.local):
            QtGui.QMessageBox.warning(None,"Error","The local path "+self.local+" do not exist or is not a directory")
            return None
        if not self.mainUi.xmlrpc.fileExists(self.mainUi.xmlrpc.myHome+'/files/'+self.remote):
            QtGui.QMessageBox.warning(None,"Error","The path "+self.remote+" do not exist or is not a directory in your eyeOS")
            return None
        self.close()
        self.mainUi.tray_icon.showMessage("Importing files","Importing files to a remote folder in your eyeOS",QtGui.QSystemTrayIcon.Information,10000)
        self.thread = Importer(self, self.local,self.remote)
        self.thread.start()
        self.mainUi.config.addSync(self.local, self.remote)
        self.mainUi.addSync(self.local,self.remote)
        
    def cancel(self):
        self.close()
        
    def browsing(self):
        filepath = QtGui.QFileDialog.getExistingDirectory()
        self.ui.lineLocal.setText(filepath)
    
    def output(self,str):
        self.mainUi.output(str)
        
        
class Importer(QThread):
    def __init__ ( self, dlg, loc, rem):
        self.dad = dlg
        self.local = loc
        self.remote = rem
        QThread.__init__(self)
    def run(self):
        self.dad.mainUi.xmlrpc.initialImport(self.local,self.remote)
        return None
        
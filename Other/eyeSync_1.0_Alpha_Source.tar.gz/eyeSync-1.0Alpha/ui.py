#!/usr/bin/python
# -*- coding: UTF8 -*-
#
# eyeSync 1.0Alpha
#
# Copyright 2008 eyeOS Team (team@eyeos.org)
#
# http://www.eyeos.org/
#
# Licensed under the terms of the GNU General Public License 3 (gpl3).
# See LICENSE for details.
#

import sys
import os
from PyQt4 import QtGui, QtCore
from config import studioConfig
from watcher import FileSystemWatcher, FileSystemEventProcess
from PyQt4.QtCore import QObject, QThread
from xmlrpc import myXmlRpc
from configure import Ui_Dialog, dlgConfigure
from addSync import Ui_Sync, SyncDlg, Importer

class MainWindow(QtGui.QMainWindow):
    def __init__(self):
        self.watchers = []
        self.xmlrpc = myXmlRpc()
        QtGui.QMainWindow.__init__(self)
        
        self.config = studioConfig()
        syncs = self.config.syncs
        
        #resize the window
        screenHeight = 600
        screenWidth = 800
        self.resize(screenWidth, screenHeight)
        
        #center the window in the screen
        screen = QtGui.QDesktopWidget().screenGeometry()
        size =  self.geometry()
        self.move((screen.width()-size.width())/2, (screen.height()-size.height())/2)
        
        #set the title
        self.setWindowTitle('eyeOS sync')
        self.statusBar()
        
        #add a statusbar
        self.information = QtGui.QTextEdit()
        self.information.setReadOnly(1)
        welcomemsg = '<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><center>eyeSync is a full featured synchronization tool to synchronize your files with <b>eyeOS</b>!'
        welcomemsg += '<br/><br/>'
        welcomemsg += '<b>1.</b>Click on <i>Preferences</i> to specify the address to your eyeOS and your account'
        welcomemsg += '<br/><br/>'
        welcomemsg += '<b>2.</b>Click on <i>Add Folder</i> and select wich folders of your computer you want to synchronize with your eyeOS'
        welcomemsg += '<br/><br/>'
        welcomemsg += '<b>3.</b>Start working and your files will be automatically updated in your eyeOS!'
        self.information.setHtml(welcomemsg)
        self.information.setStyleSheet("border:20px solid white;background-image: url("+sys.path[0]+"/gfx/syncimg.png);background-repeat: no;background-color:white;background-position: top center;")
        #self.information.setStyleSheet("background-position: top center;")
        self.events = QtGui.QTextEdit()
        self.events.setReadOnly(1)
        self.events.setHtml('<center><h1 style="color:#003366;">Event log</h1></center>&nbsp;')
        
        self.centralTab = QtGui.QTabWidget()
        #Adding tabs to tabWidget
        self.centralTab.addTab(self.information,"Sync")
        self.centralTab.addTab(self.events,"Events")
        self.setCentralWidget(self.centralTab)
        
        #qdocks
        self.syncDock = QtGui.QDockWidget("Sync Dirs", self)
        self.syncDock.setObjectName("syncDirs")
        
        self.addDockWidget(QtCore.Qt.LeftDockWidgetArea, self.syncDock)
        
        ############ List of dirs
        self.listSync = QtGui.QListWidget()
        #now, tell qt to use customcontextmenus
        self.listSync.setSelectionMode(QtGui.QListWidget.SingleSelection)
        self.listSync.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.connect(self.listSync, QtCore.SIGNAL('customContextMenuRequested(QPoint)'), self.getContextMenu); 

        for obj in syncs:
            self.addSync(obj[0], obj[1])
        
        self.syncDock.setWidget(self.listSync)
        
        #Creaitng actions
        #######################
        #sync = QtGui.QAction(QtGui.QIcon('icons/sync.png'), 'Sync', self)
        #sync.setShortcut('Ctrl+S')
        #sync.setIconText('Sync') ############## only needed if autosync off
        #sync.setStatusTip('Sync your eyeOS with your local files')
        #################
        add = QtGui.QAction(QtGui.QIcon(sys.path[0]+'/icons/add.png'), 'Add', self)
        add.setShortcut('Ctrl+A')
        add.setIconText('Add Folder')
        add.setStatusTip('Add a new folder to sync')
        #################
        pref = QtGui.QAction(QtGui.QIcon(sys.path[0]+'/icons/preferences.png'), 'Preferences', self)
        pref.setShortcut('Ctrl+P')
        pref.setIconText('Preferences')
        pref.setStatusTip('Configure eyeSync')
        #################
        about = QtGui.QAction(QtGui.QIcon(sys.path[0]+'/icons/about.png'), 'About', self)
        about.setShortcut('Ctrl+W')
        about.setIconText('About')
        about.setStatusTip('About eyeSync')
        #################
        #######################
	
        self.connect(add, QtCore.SIGNAL('triggered()'),self.doAdd)
        self.connect(pref, QtCore.SIGNAL('triggered()'),self.doPref)
        self.connect(about, QtCore.SIGNAL('triggered()'),self.doAbout)
        
        toolbar = self.addToolBar('Toolbar')
        toolbar.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
        #toolbar.addAction(sync)
        toolbar.addAction(add)
        toolbar.addAction(pref)
        toolbar.addAction(about)
        
        #Menu bar
        ####################
        self.menubar = QtGui.QMenuBar(self)
        self.menubar.setGeometry(QtCore.QRect(0,0,800,25))
        self.menubar.setObjectName("menubar")

        self.menuFIle = QtGui.QMenu(self.menubar)
        self.menuFIle.setObjectName("menuFIle")
        self.setMenuBar(self.menubar)

        self.actionQuit = QtGui.QAction(self)
        self.actionQuit.setObjectName("actionQuit")
        self.menuFIle.addAction(self.actionQuit)
        self.menubar.addAction(self.menuFIle.menuAction())
        
        #set texts
        self.menuFIle.setTitle(QtGui.QApplication.translate("MainWindow", "FIle", None, QtGui.QApplication.UnicodeUTF8))
        self.actionQuit.setText(QtGui.QApplication.translate("MainWindow", "Quit", None, QtGui.QApplication.UnicodeUTF8))
        
        #connect signals
        self.connect(self.actionQuit, QtCore.SIGNAL('triggered()'),QtCore.SLOT('close()'))
        ####################
        
        #tray icon
        ####################
        self.tray_icon = QtGui.QSystemTrayIcon()
        if sys.platform == 'darwin':
            icon = QtGui.QIcon(sys.path[0]+"/icons/tray.png")
        else:
            icon = QtGui.QIcon(sys.path[0]+"/icons/tray2.png")
        self.tray_icon.setIcon(icon)
        self.traymenu = QtGui.QMenu()
        self.hide = QtGui.QAction('Show', self)
        self.closeApp = QtGui.QAction('Quit', self)
        self.connect(self.hide, QtCore.SIGNAL('triggered()'),self.showMe)
        self.connect(self.closeApp, QtCore.SIGNAL('triggered()'),self.action_quit)
        self.traymenu.addAction(self.hide)
        self.traymenu.addAction(self.closeApp)
        self.tray_icon.setContextMenu(self.traymenu)
        self.tray_icon.show()
        ####################
    
    def action_quit(self):
        if sys.platform == 'darwin':
            os.system("killall -9 gfs")
        raise SystemExit

    def getContextMenu(self,point):
        try:
            p = self.listSync.mapToGlobal(point)
            item = self.listSync.indexAt(point)
            self.listSync.item(item.row()).setSelected(True);
            
            menu = QtGui.QMenu("Menu", self)
            
            delete = QtGui.QAction(QtGui.QIcon(sys.path[0]+'/icons/cancel.png'), 'Remove', self)
            delete.setIconText('Remove')
            delete.setStatusTip('Remove this folder from sync list')
            
            prop = QtGui.QAction(QtGui.QIcon(sys.path[0]+'/icons/prop.png'), 'Properties', self)
            prop.setIconText('Properties')
            prop.setStatusTip('View the options for this folder')
            
            self.connect(prop, QtCore.SIGNAL('triggered()'),self.doProp)
            self.connect(delete, QtCore.SIGNAL('triggered()'),self.doDelete)
            
            menu.addAction(delete)
            menu.addAction(prop)
        
            menu.exec_(p) 
        except:
            return None
        
    def doProp(self):
        item = self.listSync.currentItem()
        myData = item.data(32)
        localPath = str(myData.toString())
        obj = self.config.getObjByLocalSync(localPath)
        QtGui.QMessageBox.about(self,"Properties","Local path:\n"+localPath+"\n\nRemote path:\n"+obj[1])
        
    def doDelete(self):
        item = self.listSync.currentItem()
        myData = item.data(32)
        myItem = self.listSync.takeItem(self.listSync.currentIndex().row())
        self.listSync.removeItemWidget(item)
        localPath = str(myData.toString())
        self.config.deleteByLocalPath(localPath)
		
    def closeEvent(self,event):
        self.setVisible(False)
        event.ignore()
        
    def showMe(self):
        self.setVisible(True)
        return None
    
    def doAdd(self):
        self.add = SyncDlg(self)
        self.add.exec_()
        return None
    
    def output(self,text):
        self.events.setHtml(self.events.toHtml()+text)
        self.events.ensureCursorVisible()
    
    def addSync(self,localPath,remotePath):
        filepath = QtCore.QString(localPath)
        myWatcher = FileSystemWatcher(localPath)
        self.connect(myWatcher.thread, QtCore.SIGNAL("reply(QString)"), self.output)
        myWatcher.start()
        self.watchers.append(myWatcher)
        
        if localPath.endswith('/'):
            filepath.chop(1)
        fileInfo = QtCore.QFileInfo(filepath)
        filename = QtCore.QString(fileInfo.baseName())
        newItem = QtGui.QListWidgetItem()
        newItem.setText(filename)
        newItem.setData(32,QtCore.QVariant(localPath))
        self.listSync.insertItem(0, newItem)    
        return None
    def doPref(self):
        d = dlgConfigure()
        d.exec_()
        return None
    
    def doAbout(self):
        QtGui.QMessageBox.about(self,"About eyeSync","eyeSync 0.1 Alpha (c) the eyeOS team - www.eyeos.org")
        return None
    
    def importFiles(self,path):
        return None
        
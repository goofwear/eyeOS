#!/usr/bin/python
# -*- coding: UTF8 -*-
#
# eyeSync 1.0Alpha
#
# Copyright 2008 eyeOS Team (team@eyeos.org)
#
# http://www.eyeos.org/
#
# Licensed under the terms of the GNU General Public License 3 (gpl3).
# See LICENSE for details.
#

import sys
from PyQt4 import QtGui, QtCore
from config import studioConfig
from PyQt4.QtCore import QObject, QThread

class Ui_Dialog(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        myWidth = 320
        myHeight = 180
        Form.resize(QtCore.QSize(QtCore.QRect(0,0,myWidth,myHeight).size()).expandedTo(Form.minimumSizeHint()))
        
        self.config = studioConfig()
        
        screen = QtGui.QDesktopWidget().screenGeometry()
        Form.move((screen.width()-myWidth)/2, (screen.height()-myHeight)/2)
        
        Form.setWindowTitle('Configure eyeSync')
        
        self.labelURL = QtGui.QLabel("Server URL",Form)
        self.labelURL.move(20,30)
        
        self.labelUser = QtGui.QLabel("Username",Form)
        self.labelUser.move(20,60)
        
        self.labelPass = QtGui.QLabel("Password",Form)
        self.labelPass.move(20,90)
        
        self.okB = QtGui.QPushButton("Ok",Form)
        self.okB.setGeometry(QtCore.QRect(240,145,70,25))
        
        self.cancelB = QtGui.QPushButton("Cancel",Form)
        self.cancelB.setGeometry(QtCore.QRect(160,145,70,25))
        
        self.lineURL = QtGui.QLineEdit(Form)
        self.lineURL.setGeometry(QtCore.QRect(100,30,210,20))
        self.lineURL.setText(self.config.eyePath)
        
        self.lineUser = QtGui.QLineEdit(Form)
        self.lineUser.setGeometry(QtCore.QRect(100,60,210,20))
        self.lineUser.setText(self.config.username)
        
        self.linePass = QtGui.QLineEdit(Form)
        self.linePass.setGeometry(QtCore.QRect(100,90,210,20))
        self.linePass.setEchoMode(QtGui.QLineEdit.Password) 
        self.linePass.setText(self.config.password)
        
        
class dlgConfigure(QtGui.QDialog):

    def __init__(self):

        QtGui.QDialog.__init__(self)
        
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        
        self.connect(self.ui.okB, QtCore.SIGNAL("clicked()"),self.accept)
        self.connect(self.ui.cancelB, QtCore.SIGNAL("clicked()"),self.cancel)

    def accept(self):
        url = str(self.ui.lineURL.text())
        username = str(self.ui.lineUser.text())
        password = str(self.ui.linePass.text())
        if url[:len("http://")] != "http://" and url[:len("https://")] != "https://":
            url = "http://"+url
        if not url.endswith("index.php?api=1"):
            if url.endswith("index.php"):
                url = url+"?api=1"
            else:
                url = url+"index.php?api=1"
        self.ui.config.changePrefs(url,username,password)
        QtGui.QMessageBox.information(self,"Restart required","You need to restart eyeSync before this changes take effect")
        self.close()
        
    def cancel(self):
        self.close()
        
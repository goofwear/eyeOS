#!/usr/bin/python
# -*- coding: UTF8 -*-
#
# eyeSync 1.1Alpha
#
# Copyright 2008 eyeOS Team (team@eyeos.org)
#
# http://www.eyeos.org/
#
# Licensed under the terms of the GNU General Public License 3 (gpl3).
# See LICENSE for details.
#

import locale
import sys

class localCharset:
    def __init__(self):
        return None
    
    def getCharset(self):
        # init default Unicode string encoding (ascii)
        uencoding='ascii'
        # check if local python installation forces something else in site.py (default=ascii)
        try:
            import site
            uencoding=site.encoding
        except: pass
        
        # check system locale for proper Unicode string encoding
        import locale
        if uencoding=='ascii' and locale.getdefaultlocale()[1]:
            uencoding = locale.getdefaultlocale()[1]
        
        # if we are on MacOSX, we default to UTF8
        # because apples python reports 'ISO8859-1' as locale, but MacOSX uses utf8
        if sys.platform=='darwin':
            uencoding='utf8'
        
        return uencoding

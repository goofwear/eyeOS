#!/usr/bin/python
# -*- coding: UTF8 -*-
import sys
from PyQt4 import QtGui, QtCore
from ui import MainWindow

app = QtGui.QApplication(sys.argv)
main = MainWindow()
main.show()
sys.exit(app.exec_())
#!/usr/bin/python
# -*- coding: UTF8 -*-
#
# eyeSync 1.1Alpha
#
# Copyright 2008 eyeOS Team (team@eyeos.org)
#
# http://www.eyeos.org/
#
# Licensed under the terms of the GNU General Public License 3 (gpl3).
# See LICENSE for details.
#

import sys
import os
from PyQt4 import QtGui, QtCore
from config import studioConfig
from PyQt4.QtCore import QObject, QThread
import xmlrpclib
import base64

class myXmlRpc(QtCore.QObject):
    def __init__(self):
        self.config = studioConfig()
        try:
            self.server = xmlrpclib.Server(self.config.eyePath)
            self.myHome = self.server.service.um.getCurrentUserDir(self.config.username,self.config.password,[0])
        except:
            QtGui.QMessageBox.warning(None,"Configuration error","Your eyeOS server, username or password seem to be incorrect or not updated yet. Please fill in those informations in the Preferences panel.")
        return None
    
    def initialImport(self,local,remote):
        myPath = self.myHome + 'files/'+remote
        list = self.server.service.vfs.getDirContent(self.config.username,self.config.password,[myPath])    
        self.makeImport(local,myPath)
        return None
    def makeImport(self,local,remote):
        myFiles = os.listdir(local)
        print "Checking if "+remote+" exists"
        if not self.fileExists(remote):
            print "Creating "+remote
            self.server.service.vfs.mkdir(self.config.username,self.config.password,[remote])
        for file in myFiles:
            if os.path.isdir(local+'/'+file):
                self.makeImport(local+'/'+file, remote+'/'+file)
            else:
                print "importing: "+local+'/'+file
                f = open(local+'/'+file, "rb")
                content = f.read(1024)
                self.server.service.vfs.create(self.config.username,self.config.password,[remote+'/'+file])
                while content:
                    b64content = base64.encodestring(content)
                    self.server.service.vfs.appendToFileBinary(self.config.username,self.config.password,[remote+'/'+file,b64content])
                    content = f.read(1024)
                f.close()
        return None
    
    def updateFile(self,local,remote):
        myPath = self.myHome+'files/'+remote
        if not self.fileExists(myPath):
            self.server.service.vfs.create(self.config.username,self.config.password,[myPath])
        else:
            self.server.service.vfs.erase(self.config.username,self.config.password,[myPath])
        f = open(local, "rb")
        content = f.read(1024)
        while content:
            b64content = base64.encodestring(content)
            self.server.service.vfs.appendToFileBinary(self.config.username,self.config.password,[myPath,b64content])
            content = f.read(1024)
        f.close()
        return None
    
    def createFile(self,local,remote):
        myPath = self.myHome+'files/'+remote
        if os.path.isdir(local):
            self.mkdir(remote)
        else:
            self.server.service.vfs.create(self.config.username,self.config.password,[myPath])
        return None
    
    def deleteFile(self,local,remote):
        myPath = self.myHome+'files/'+remote
        self.server.service.vfs.delete(self.config.username,self.config.password,[myPath])
        return None
    def renameFile(self,fr,to):
        myFPath = self.myHome+'files/'+fr
        myTPath = self.myHome+'files/'+to
        self.server.service.vfs.rename(self.config.username,self.config.password,[myFPath,myTPath])
    def mkdir(self,what):
        folderPath = self.myHome+'files/'+what
        self.server.service.vfs.mkdir(self.config.username,self.config.password,[folderPath])
    def fileExists(self,what):
        return self.server.service.vfs.fileExists(self.config.username,self.config.password,[what])
         

#!/usr/bin/python
# -*- coding: UTF8 -*-
#
# eyeSync 1.1Alpha
#
# Copyright 2008 eyeOS Team (team@eyeos.org)
#
# http://www.eyeos.org/
#
# Licensed under the terms of the GNU General Public License 3 (gpl3).
# See LICENSE for details.
#

import sys
import os.path
import xml.dom.minidom

class studioConfig:
    
    def __init__(self):
        self.path = os.path.join(os.path.expanduser('~') , '.eyeSync')
        if os.path.exists(self.path):
            doc = xml.dom.minidom.parse(self.path+'/config.xml')
            myPath = doc.getElementsByTagNameNS(None, "path")
            myUser = doc.getElementsByTagNameNS(None, "username")
            myPass = doc.getElementsByTagNameNS(None, "password")
            self.eyePath = myPath[0].childNodes[0].nodeValue
            self.username = myUser[0].childNodes[0].nodeValue
            self.password = myPass[0].childNodes[0].nodeValue
            self.syncs = self.getSyncs()
        else:
            os.mkdir(self.path)
            doc = xml.dom.minidom.Document()
            element = doc.createElementNS(None, "config")
            myPath = doc.createElementNS(None,"path")
            myUser = doc.createElementNS(None,"username")
            myPass = doc.createElementNS(None,"password")
            mySyncs = doc.createElementNS(None,"syncs")
            element.appendChild(myPath)
            element.appendChild(myUser)
            element.appendChild(myPass)
            element.appendChild(mySyncs)
            myPath.appendChild(doc.createTextNode("http://127.0.0.1/eyeOS/index.php?api=1"))
            myUser.appendChild(doc.createTextNode("test"))
            myPass.appendChild(doc.createTextNode("test"))
            doc.appendChild(element)
            file_object = open(self.path+'/config.xml', "w")
            file_object.write(doc.toxml())
            file_object.close()
            self.eyePath = "http://www.eyeos.info/index.php?api=1"
            self.username = "test"
            self.password = "test"
        return None
    def changePrefs(self,path,username,password):
        print "changing prefs!"
        doc = xml.dom.minidom.parse(self.path+'/config.xml')
        myPath = doc.getElementsByTagNameNS(None, "path")
        myUser = doc.getElementsByTagNameNS(None, "username")
        myPass = doc.getElementsByTagNameNS(None, "password")    
        
        myPath[0].childNodes[0].nodeValue = path
        myUser[0].childNodes[0].nodeValue = username
        myPass[0].childNodes[0].nodeValue = password  
        
        file_object = open(self.path+'/config.xml', "w")
        file_object.write(doc.toxml())
        file_object.close()
        
        self.eyePath = path
        self.username = username
        self.password = password
    
    def addSync(self,localpath,remotepath):
        doc = xml.dom.minidom.parse(self.path+'/config.xml')
        root = doc.getElementsByTagNameNS(None, "syncs")
        root = root[0]
        
        mySync = doc.createElementNS(None,"sync")
        root.appendChild(mySync)
        myLocal = doc.createElementNS(None,"localPath")
        myLocal.appendChild(doc.createTextNode(localpath))
        myRemote = doc.createElementNS(None,"remotePath")
        myRemote.appendChild(doc.createTextNode(remotepath))
        mySync.appendChild(myLocal)
        mySync.appendChild(myRemote)
        file_object = open(self.path+'/config.xml', "w")
        file_object.write(doc.toxml())
        file_object.close()
        self.syncs.append([localpath,remotepath])
        
    def getSyncs(self):
        doc = xml.dom.minidom.parse(self.path+'/config.xml')
        root = doc.getElementsByTagNameNS(None, "sync")
        
        mySyncs = []
        for current in root:
            myLocalPath = current.getElementsByTagNameNS(None, "localPath")
            myLocalPath = myLocalPath[0].childNodes[0].nodeValue
            myRemotePath = current.getElementsByTagNameNS(None, "remotePath")
            myRemotePath = myRemotePath[0].childNodes[0].nodeValue
            mySyncs.append([myLocalPath,myRemotePath])
        return mySyncs
    
    def deleteByLocalPath(self,local):
        doc = xml.dom.minidom.parse(self.path+'/config.xml')
        root = doc.getElementsByTagNameNS(None, "sync")
        
        mySyncs = []
        for current in root:
            myLocalPathI = current.getElementsByTagNameNS(None, "localPath")
            myLocalPath = myLocalPathI[0].childNodes[0].nodeValue
            if myLocalPath == local:
                myLocalPathI[0].parentNode.parentNode.removeChild(myLocalPathI[0].parentNode)
                file_object = open(self.path+'/config.xml', "w")
                file_object.write(doc.toxml())
                file_object.close()
                return True
        return False
        
    def getObjByLocalSync(self,local):
        for obj in self.syncs:
            tlocal = local[:len(obj[0])]
            if tlocal == obj[0]:
                return obj
        return None  







